/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'slurp\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-logo-causely': '&#xe62b;',
		'icon-logo-causely-thin': '&#xe635;',
		'icon-logo-causely-stroke': '&#xe636;',
		'icon-logo-causely-fill': '&#xe62e;',
		'icon-logo-reach-pin': '&#xe638;',
		'icon-logo-checkin-angels': '&#xe62f;',
		'icon-logo-angels-sweat': '&#xe630;',
		'icon-logo-checkin-angels-alt': '&#xe639;',
		'icon-logo-sweat-angels-alt': '&#xe63a;',
		'icon-infographic-conversion': '&#xe601;',
		'icon-infographic-talk': '&#xe602;',
		'icon-infographic-share': '&#xe603;',
		'icon-infographic-network': '&#xe611;',
		'icon-infographic-network-alt': '&#xe62c;',
		'icon-punk-education': '&#xe63b;',
		'icon-punk-dog': '&#xe63c;',
		'icon-punk-house': '&#xe63d;',
		'icon-punk-food': '&#xe607;',
		'icon-punk-animal-food': '&#xe612;',
		'icon-punk-veteran': '&#xe613;',
		'icon-punk-animal': '&#xe605;',
		'icon-punk-rainforest': '&#xe606;',
		'icon-punk-health': '&#xe608;',
		'icon-punk-water': '&#xe609;',
		'icon-punk-school': '&#xe60a;',
		'icon-punk-environment': '&#xe60b;',
		'icon-punk-child': '&#xe60c;',
		'icon-punk-plant': '&#xe60d;',
		'icon-punk-pig': '&#xe60e;',
		'icon-punk-dogfooding': '&#xe631;',
		'icon-punk-dalek': '&#xe60f;',
		'icon-metrics-heart': '&#xe024;',
		'icon-metrics-impression': '&#xe2d9;',
		'icon-metrics-share': '&#xe62d;',
		'icon-metrics-referral': '&#xe610;',
		'icon-double-quote': '&#xe977;',
		'icon-quotes-right': '&#xe978;',
		'icon-power': '&#xe086;',
		'icon-loader': '&#xe105;',
		'icon-menu': '&#xe120;',
		'icon-repeat': '&#xe058;',
		'icon-ban': '&#xe107;',
		'icon-open': '&#xe128;',
		'icon-trash': '&#xe109;',
		'icon-cog': '&#xe023;',
		'icon-arrow-back': '&#xe039;',
		'icon-mail': '&#xe002;',
		'icon-speech-bubble': '&#xe076;',
		'icon-lock': '&#xe007;',
		'icon-paper-clip': '&#xe001;',
		'icon-box': '&#xe079;',
		'icon-signal': '&#xe011;',
		'icon-help': '&#xe127;',
		'icon-globe': '&#xe078;',
		'icon-search': '&#xe036;',
		'icon-location-gps': '&#xe071;',
		'icon-plus': '&#xe114;',
		'icon-ellipsis': '&#xe129;',
		'icon-star': '&#xe093;',
		'icon-briefcase': '&#xe075;',
		'icon-map': '&#xe072;',
		'icon-head': '&#xe074;',
		'icon-arrow-up': '&#xe096;',
		'icon-arrow-right': '&#xe095;',
		'icon-arrow-down': '&#xe097;',
		'icon-arrow-left': '&#xe094;',
		'icon-minus': '&#xe115;',
		'icon-check': '&#xe116;',
		'icon-cross': '&#xe117;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
